$("#ex8").slider({
    tooltip: 'always'
});
