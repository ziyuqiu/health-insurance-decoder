  $("#slider1").change(function () {           
     var newValue = $('#slider1').val();
     $("#score").html(newValue);
  });
